-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2024-04-20 02:01:20
-- 服务器版本： 10.4.32-MariaDB
-- PHP 版本： 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `webwizards`
--

-- --------------------------------------------------------

--
-- 表的结构 `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` varchar(100) NOT NULL,
  `activity` varchar(50) NOT NULL,
  `peopleNum` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `fromTime` varchar(50) NOT NULL,
  `toTime` varchar(50) NOT NULL,
  `imageSrc` varchar(50) NOT NULL,
  `people` varchar(100) NOT NULL,
  `author` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `activity`, `peopleNum`, `date`, `fromTime`, `toTime`, `imageSrc`, `people`, `author`) VALUES
(1, 'test', 'test', 'hiking', 3, '2024-4-10', '8:00', '12:00', 'hiking.jpeg', 'Joe Doe, Ives Li, Ivesli', 'IvesLi'),
(3, 'test max', 'test max', 'swimming', 1, '2024-4-18', '8:00', '12:00', 'swimming.jpeg', 'user1', 'user1'),
(4, 'post by user2', 'test', 'Football', 4, '2024-05-13', '14:25', '15:25', 'football.jpeg', 'user2, Ivesli, Ivesli', 'user2'),
(5, 'Ivesli', 'tset home', 'Hiking', 4, '2024-04-30', '14:40', '15:36', 'hiking.jpeg', 'Ivesli, bob', 'Ivesli'),
(6, 'climb Lantau Island', 'Join me and climb Lantau Island', 'Hiking', 3, '2024-04-26', '13:09', '17:09', 'hiking.jpeg', 'Ivesli, Michael, alice', 'Ivesli');

--
-- 转储表的索引
--

--
-- 表的索引 `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
